import numpy as np

data = [0, 4, 4, 1, 0, 2, 5, 8, 6, 2]
matrix = np.array(data).reshape(2, 5)

random_matrix1 = np.random.randint(0, 10, size=(2, 5))
random_matrix2 = np.random.randint(0, 10, size=(2, 5))

sum_result = random_matrix1 + random_matrix2
mul_result = random_matrix1 * random_matrix2

print(matrix)
print(random_matrix1)
print(random_matrix2)
print(sum_result)
print(mul_result)
