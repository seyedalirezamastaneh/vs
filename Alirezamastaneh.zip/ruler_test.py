n = int(input())
for i in range(1, n + 1):
    print("|", end="")
    if i % 10 == 0:
        print(i, end="")
    else:
        print(" ", end="")
