n = int(input())
i = 0
while i <= n:
    print(2**i)
    i += 1
